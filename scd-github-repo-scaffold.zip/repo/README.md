# Sickle Cell Disease: Genotype–Phenotype Clustering Analysis

Analysis pipeline linking phased genotype calls to clinical phenotype and
complication data in a sickle cell disease (SCD) cohort from the *All of Us*
Research Program, using UMAP and clustering to characterize subgroups by
clinical severity.

> **Data note:** This repository contains code only. See
> [`DATA_AVAILABILITY.md`](DATA_AVAILABILITY.md) for why the underlying
> participant-level data is not included and how to obtain your own access.

## Repository structure

```
.
├── notebooks/
│   ├── phased.ipynb              # Extract phased WGS genotype calls (Hail)
│   ├── pheno.ipynb               # Define SCD cohort; derive demographics,
│   │                              # complications, severity, and lab phenotypes
│   ├── pheno_geno.ipynb          # Merge genotype + phenotype into one dataset
│   └── UMAP_machine_learning.ipynb  # UMAP + clustering + cluster characterization
├── requirements.txt
├── DATA_AVAILABILITY.md
├── LICENSE
└── README.md
```

## Pipeline overview

1. **`phased.ipynb`** — Uses [Hail](https://hail.is/) on the All of Us
   Researcher Workbench to subset phased short-read WGS VCFs to target
   positions of interest (multiple chromosomes), then parses the resulting
   VCFs into wide-format genotype tables.
2. **`pheno.ipynb`** — Queries the All of Us Controlled Tier CDR to build the
   SCD cohort, pull demographics (age, sex, race/ethnicity), identify the
   top 10 SCD-related complications, assign a severity classification, and
   extract relevant lab measurements (e.g. hemoglobin, fetal hemoglobin).
3. **`pheno_geno.ipynb`** — Merges the genotype table from `phased.ipynb`
   with the phenotype/complication table from `pheno.ipynb` on participant
   ID into a single master analysis dataset.
4. **`UMAP_machine_learning.ipynb`** — Computes Gower distance over mixed
   categorical/numeric features, runs UMAP for dimensionality reduction,
   clusters participants (k-medoids / k-means, selected via silhouette
   score), and summarizes clinical characteristics per cluster.

## Setup

```bash
git clone https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git
cd YOUR_REPO_NAME
python -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

The genomics notebooks (`phased.ipynb`, `pheno.ipynb`) are written to run
inside the All of Us Researcher Workbench, where `GOOGLE_PROJECT`,
`WORKSPACE_BUCKET`, and `WORKSPACE_CDR` are pre-set for each user's
workspace. `UMAP_machine_learning.ipynb` and `pheno_geno.ipynb` run on any
standard Python environment once the intermediate CSVs exist locally.

## Requirements

See [`requirements.txt`](requirements.txt). Key libraries: `pandas`,
`numpy`, `scikit-learn`, `umap-learn`, `gower`, `pyclustering`, `seaborn`,
`matplotlib`, `hail`, `google-cloud-bigquery`.

## Citation

If you use this code, please cite:

> [Author names]. [Paper title]. [Journal], [Year]. DOI: [add once assigned]

A citable Zenodo DOI for this code repository will be added here once the
first release is tagged.

## License

Released under the [MIT License](LICENSE).
